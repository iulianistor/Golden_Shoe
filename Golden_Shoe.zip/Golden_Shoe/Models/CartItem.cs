﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Models
{
    public class CartItem
    {
        public int StockId { get; set; }
        public double Size { get; set; }
        public string Name { get; set; }
        public int StockNumber { get; set; }
        public int Quanity { get; set; }
        public double Price { get; set; }
        public CartItem(int stockId, string shoeName, int stock, int quantity, double size, double price)
        {
            this.StockId = stockId;
            this.Name = shoeName;
            this.StockNumber = stock;
            this.Quanity = quantity;
            this.Size = size;
            this.Price = price;
        }

    }
}
