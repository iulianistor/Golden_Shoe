﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Models
{
    public class Stock
    {
        [Key]
        public int StockId { get; set; }

        [Required]
        public double Size { get; set; }

        [Required]
        public int Quantity { get; set; }

        //FK
        [Required]
        [ForeignKey("Shoe")]
        public int ShoeId { get; set; }
        public virtual Shoe Shoe { get; set; }  //loading the shoe as well, in order to have only one DB call
    }
}
