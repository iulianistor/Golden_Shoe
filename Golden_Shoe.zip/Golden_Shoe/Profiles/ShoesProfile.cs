﻿using AutoMapper;
using Golden_Shoe.DTOs;
using Golden_Shoe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Profiles
{
    public class ShoesProfile : Profile
    {
        public ShoesProfile()
        {
            //Source -> Target
            CreateMap<Shoe, ShoeReadDto>();
            CreateMap<ShoeAddDto, Shoe>();
        }

    }
}
