﻿
using Golden_Shoe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Data
{
    public interface IStock
    {
        bool SaveChanges();
        IEnumerable<Stock> GetStock();
        void Buy(Stock stock);
        IEnumerable<Stock> GetStockByShoeId(int shoeID);
        Stock GetStockById(int stockID);
    }
}
