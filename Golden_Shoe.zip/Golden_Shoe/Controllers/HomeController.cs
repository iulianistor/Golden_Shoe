﻿using AutoMapper;
using Golden_Shoe.Data;
using Golden_Shoe.DTOs;
using Golden_Shoe.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Golden_Shoe.Controllers
{

    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IShoe _shoeRepository;
        private readonly IStock _stockRepository;
        private readonly IMapper _mapper;

        public HomeController(ILogger<HomeController> logger, IShoe shoeRepo, IStock stockRepo, IMapper mapper)
        {
            _logger = logger;
            _shoeRepository = shoeRepo;
            _stockRepository = stockRepo;
            _mapper = mapper;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Cart()
        {
            var myCart = HttpContext.Request.Cookies["MyClientCart"];
            var myDeserializedCart = new List<CartItem>();

            if (!string.IsNullOrEmpty(myCart))
            {
                myDeserializedCart = JsonConvert.DeserializeObject<List<CartItem>>(myCart);
            }

            return View(myDeserializedCart);
        }

        public List<ShoeReadDto> GetShoeDtos()
        {
            var shoeList = new List<ShoeReadDto>();

            var shoes = _shoeRepository.GetAllShoes();
            foreach (Shoe shoe in shoes)
            {
                shoeList.Add(new ShoeReadDto
                {
                    ShoeId = shoe.ShoeId,
                    Name = shoe.Name,
                    Gender = shoe.Gender,
                    Price = shoe.Price,
                    Description = shoe.Description,
                    IsAvailable = shoe.StockItems.Count > 0 && shoe.StockItems.Any(x => x.Quantity > 0)
                });
            }
            return shoeList;
        }

        public IActionResult Collection()
        {
            var shoeDtoList = GetShoeDtos();
            return View(shoeDtoList);
        }       

      //[HttpGet("{action}")]
        public ActionResult<IEnumerable<ShoeReadDto>> GetAllShoes()
        {
            var shoes = _shoeRepository.GetAllShoes();
            return Ok(_mapper.Map<IEnumerable<ShoeReadDto>>(shoes));
        }
               
      //[HttpGet("{action}/{id}")]
        public ActionResult<ShoeReadDto> GetShoeById(int id)
        {
            var shoe = _shoeRepository.GetShoeById(id);
            if(shoe != null)
            {
                return Ok(_mapper.Map<ShoeReadDto>(shoe));
            }
            return NotFound();
        }
   
     //[HttpGet("{action}")]
        public ActionResult<IEnumerable<Stock>> GetStock()
        {
            var stock = _stockRepository.GetStock();
            return Ok(stock);
        }

      //HttpPost("{action}")] 
        public ActionResult<ShoeReadDto> AddShoe([FromBody]ShoeAddDto newShoe)
        {
            var shoeModel = _mapper.Map<Shoe>(newShoe);
            _shoeRepository.AddShoe(shoeModel);  
            _shoeRepository.SaveChanges();

            var shoeReadDto = _mapper.Map<ShoeReadDto>(shoeModel);
            return Ok(shoeReadDto);
        }

        public ActionResult Details(int id)
        {
            var shoeModelFromRepo = _shoeRepository.GetShoeById(id);
            if (shoeModelFromRepo == null)
            {
                return NotFound();
            }
            var stock = _stockRepository.GetStockByShoeId(id);

            return View("Details", stock);
        }

        public ActionResult AddToCart(int id)
        {
            var stockModelFromRepo = _stockRepository.GetStockById(id);
            if (stockModelFromRepo == null)
            {
                return NotFound();
            }

            var cartItem = new CartItem(stockModelFromRepo.StockId, stockModelFromRepo.Shoe.Name, stockModelFromRepo.Quantity, 1, stockModelFromRepo.Size, stockModelFromRepo.Shoe.Price);
            var myCart = HttpContext.Request.Cookies["MyClientCart"];
            var myDeserializedCart = new List<CartItem>();

            if (!string.IsNullOrEmpty(myCart))
            {
               myDeserializedCart = JsonConvert.DeserializeObject<List<CartItem>>(myCart);
            }

            myDeserializedCart.Add(cartItem);
            HttpContext.Response.Cookies.Append("MyClientCart", JsonConvert.SerializeObject(myDeserializedCart));
           
            return View("Cart", myDeserializedCart);
        }

        public ActionResult Buy()
        {
            var myCart = HttpContext.Request.Cookies["MyClientCart"];
            var myDeserializedCart = new List<CartItem>();

            if (!string.IsNullOrEmpty(myCart))
            {
                myDeserializedCart = JsonConvert.DeserializeObject<List<CartItem>>(myCart);
            }

            foreach(CartItem item in myDeserializedCart)
            {
                var shoeModelFromRepo = _stockRepository.GetStockById(item.StockId);
                _stockRepository.Buy(shoeModelFromRepo);
            }

            HttpContext.Response.Cookies.Delete("MyClientCart");

            var shoeDtoList = GetShoeDtos();
            return View("OrderComplete");
            //return View("Collection", shoeDtoList);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public ActionResult OrderComplete()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        public ActionResult DeliveryReturns()
        {
            return View("ContactUs");
        }

    }
}
