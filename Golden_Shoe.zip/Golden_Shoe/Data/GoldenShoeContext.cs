﻿using Golden_Shoe.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Data
{
    public class GoldenShoeContext : DbContext
    {
        public GoldenShoeContext(DbContextOptions<GoldenShoeContext> opt) : base(opt)
        {

        }

        public DbSet<Shoe> Shoes { get; set; }
        public DbSet<Stock> Stocks { get; set; }

    }
}
