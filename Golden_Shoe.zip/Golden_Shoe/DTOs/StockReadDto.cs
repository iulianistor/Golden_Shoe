﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.DTOs
{
    public class StockReadDto
    {
        public int StockId { get; set; }

        public double Size { get; set; }

        public int Quantity { get; set; }
 
        public int ShoeId { get; set; }
    }
}
