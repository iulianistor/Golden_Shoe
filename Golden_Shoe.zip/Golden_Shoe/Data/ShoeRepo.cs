﻿using Golden_Shoe.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Data
{
    public class ShoeRepo : IShoe
    {
        private readonly GoldenShoeContext _context;
        public ShoeRepo(GoldenShoeContext context)
        {
            _context = context;
        } 
        public void AddShoe(Shoe shoe)
        {
            if (shoe == null)
            {
                throw new ArgumentNullException(nameof(shoe));
            }

            _context.Shoes.Add(shoe);

        }

        public IEnumerable<Shoe> GetAllShoes()
        {
            return _context.Shoes.Include(p => p.StockItems).ToList();
        }

        public Shoe GetShoeById(int id)
        {
            return _context.Shoes.FirstOrDefault(p => p.ShoeId == id); 
        }

        public bool SaveChanges()
        {
           return _context.SaveChanges()>=0;
        }
    }
}
