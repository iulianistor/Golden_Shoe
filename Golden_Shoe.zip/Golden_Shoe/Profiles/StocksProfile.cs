﻿using AutoMapper;
using Golden_Shoe.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Profiles
{
    public class StocksProfile : Profile
    {
        public StocksProfile()
        {
            CreateMap<StocksProfile, StockReadDto>();
        }
    }
}
