﻿using Golden_Shoe.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Data
{
    public class StockRepo : IStock
    {
        private readonly GoldenShoeContext _context;
        private List<Stock> stockForShoeId;
        private Shoe shoe;
        public StockRepo(GoldenShoeContext context)
        {
            _context = context;
        }
       
        public IEnumerable<Stock> GetStock()
        {
            return _context.Stocks.ToList();
        }

        public IEnumerable<Stock> GetStockByShoeId(int shoeID)
        {
            stockForShoeId = _context.Stocks.Where(s => s.ShoeId == shoeID).ToList();
            return stockForShoeId;
        }

        public Stock GetStockById(int stockID)
        {
            return _context.Stocks.Include(p => p.Shoe).FirstOrDefault(p => p.StockId == stockID);
        }

          public void Buy(Stock stock)
        {
            stock.Quantity -= 1;
            _context.SaveChanges();
        }

        public bool SaveChanges()
        {
           return (_context.SaveChanges()>=0);
        }
    }
}
