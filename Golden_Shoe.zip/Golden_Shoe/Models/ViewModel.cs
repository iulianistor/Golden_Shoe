﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Models
{
   /** public class ViewModel
    {
        public Shoe shoe {get; set;}
        public Stock stock { get; set; }

    } **/
}
