﻿using Golden_Shoe.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Golden_Shoe.Data
{
    public interface IShoe
    {
        bool SaveChanges();

        IEnumerable<Shoe> GetAllShoes();
        Shoe GetShoeById(int id);
        void AddShoe(Shoe shoe);
        

    }
}
